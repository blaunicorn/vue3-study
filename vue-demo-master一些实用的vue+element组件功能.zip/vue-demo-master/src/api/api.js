export default {
  shareholder: {
    addShareHolder: "",
    deleteHolder: function(id) {
      return `*****/${id}`;
    }
  }
}