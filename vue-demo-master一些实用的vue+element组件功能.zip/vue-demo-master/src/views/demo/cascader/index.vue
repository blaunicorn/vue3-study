<template>
  <div>
    <Cascader></Cascader>
  </div>
</template>

<script>
  import Cascader from '@/components/Cascader.vue'
  export default {
    name: 'magnifying',
    components: {
      Cascader
    }
  }
</script>