<template>
  <div>
    <magnifier></magnifier>
  </div>
</template>

<script>
  import Magnifier from '@/components/magnifier.vue'
  export default {
    name: 'magnifying',
    components: {
      Magnifier
    }
  }
</script>