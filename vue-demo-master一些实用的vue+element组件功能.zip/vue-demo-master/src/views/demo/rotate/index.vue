<template>
  <div>
    <Rotate />
  </div>
</template>

<script>
  import Rotate from '@/components/rotate.vue'
  export default {
    name: 'rotateOrangination',
    components: {
      Rotate
    }
  }
</script>