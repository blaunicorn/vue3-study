<template>
  <div>
    <!-- <h1>首页</h1> -->
    <div class="block">
      <h2>Wellcome</h2>
    </div>
  </div>
</template>

<script>
  export default {

  }
</script>
<style scoped>
.item {
  padding: 15px;
}
.ml {
  margin-left: 30px;
}
</style>