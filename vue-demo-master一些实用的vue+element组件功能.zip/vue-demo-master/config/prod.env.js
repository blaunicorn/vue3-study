module.exports = {
  MODE_ENV: '"production'
}