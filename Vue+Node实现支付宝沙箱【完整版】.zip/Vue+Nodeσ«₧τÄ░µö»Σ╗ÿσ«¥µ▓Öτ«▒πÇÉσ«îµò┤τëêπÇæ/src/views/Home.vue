<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" />
    <button @click='goPayment'>去支付</button>
  </div>
</template>

<script>
// @ is an alias to /src
import axios from 'axios'
import qs from 'qs'
export default {
  name: "Home",
  methods:{
  	goPayment(){

  		let data = {
  			orderId : 'a1234566574348545443389'
  		}
  		axios({
  			url:'/api/payment',
  			method:"post",
  			headers:{
  				'content-type':'application/x-www-form-urlencoded'
  			},
  			data:qs.stringify(data)
  		}).then(res=>{
  			window.location.href = res.data.result;
  		})

  	}
  }
  
};
</script>
